import { useEffect, useState } from 'react';
import { getProducts, createProduct } from '../api/products';
import { errorMessage } from '../api/client';
import { money } from '../utils/format';

const emptyForm = { name: '', unit: '', defaultPrice: '', barcode: '' };

export default function Products() {
  const [products, setProducts] = useState([]);
  const [filter, setFilter] = useState('');
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      setProducts(await getProducts());
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  // Runs once when the page opens.
  useEffect(() => { load(); }, []);

  const setField = (name) => (e) => setForm({ ...form, [name]: e.target.value });

  async function handleAdd(e) {
    e.preventDefault();
    setError(''); setMessage('');
    setBusy(true);
    try {
      await createProduct({
        name: form.name.trim(),
        unit: form.unit.trim() || null,
        defaultPrice: form.defaultPrice === '' ? null : Number(form.defaultPrice),
        barcode: form.barcode.trim() || null, // blank must be null: barcodes are unique
        currentStock: 0,                      // stock comes in through Deliveries
      });
      setForm(emptyForm);
      setMessage('Product added. Record a delivery to bring it into stock.');
      load();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  const visible = products.filter((p) => p.name.toLowerCase().includes(filter.trim().toLowerCase()));

  return (
    <div>
      <h2>Products</h2>

      <div className="columns">
        <div className="main">
          <div className="card">
            <input
              placeholder="Search products…"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              style={{ width: '100%', maxWidth: 360 }}
            />

            <div className="scroll-x" style={{ marginTop: 12 }}>
              <table>
                <thead>
                  <tr><th>Product</th><th>Unit</th><th>Selling price</th><th>Barcode</th></tr>
                </thead>
                <tbody>
                  {visible.length === 0 && (
                    <tr><td colSpan="4" className="muted">
                      {products.length === 0 ? 'No products yet. Add your first one.' : 'No products match your search.'}
                    </td></tr>
                  )}
                  {visible.map((p) => (
                    <tr key={p.id}>
                      <td>{p.name}</td>
                      <td>{p.unit || '-'}</td>
                      <td>{p.defaultPrice != null ? money(p.defaultPrice) : <span className="muted">not set</span>}</td>
                      <td>{p.barcode || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="muted">{products.length} product{products.length === 1 ? '' : 's'} in total</p>
          </div>
        </div>

        <div className="side">
          <form className="card stack" onSubmit={handleAdd}>
            <h3>Add a new product</h3>
            <p className="muted">Put the size in the name, e.g. “Apple Juice 1L” and “Apple Juice 500 ml” are separate products.</p>
            <input placeholder="Product name" value={form.name} onChange={setField('name')} required />
            <input placeholder="Unit (kg, pcs, bottles)" value={form.unit} onChange={setField('unit')} />
            <input type="number" min="0" step="0.01" placeholder="Selling price"
                   value={form.defaultPrice} onChange={setField('defaultPrice')} />
            <input placeholder="Barcode (optional)" value={form.barcode} onChange={setField('barcode')} />
            {error && <p className="error">{error}</p>}
            {message && <p className="success">{message}</p>}
            <button type="submit" disabled={busy}>{busy ? 'Adding…' : 'Add product'}</button>
          </form>
        </div>
      </div>
    </div>
  );
}
