import api from './client';

export const getProducts = () => api.get('/products').then((r) => r.data);
