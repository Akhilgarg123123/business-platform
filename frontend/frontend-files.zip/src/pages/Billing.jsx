import { useEffect, useState } from 'react';
import { searchCustomers, createCustomer } from '../api/customers';
import { getProducts } from '../api/products';
import { createTransaction } from '../api/transactions';
import { getPreferences } from '../api/preferences';
import { errorMessage } from '../api/client';
import { money } from '../utils/format';

const today = () => new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD in local time
const newRow = () => ({ key: crypto.randomUUID(), text: '', product: null, quantity: '1', price: '' });

export default function Billing() {
  const [phone, setPhone] = useState('');
  const [customer, setCustomer] = useState(null);
  const [notFound, setNotFound] = useState(false);
  const [newName, setNewName] = useState('');

  const [products, setProducts] = useState([]);
  const [rows, setRows] = useState([newRow()]);
  const [prefs, setPrefs] = useState(null);
  const [skipSend, setSkipSend] = useState(false);

  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  // Load product list + preferences once when the page opens.
  useEffect(() => {
    Promise.all([getProducts(), getPreferences()])
      .then(([p, pr]) => { setProducts(p); setPrefs(pr); })
      .catch((e) => setError(errorMessage(e)));
  }, []);

  // ---- customer lookup ----
  async function findCustomer() {
    setError(''); setMessage(''); setCustomer(null); setNotFound(false);
    if (!phone.trim()) return;
    try {
      const res = await searchCustomers(phone.trim());
      const found = Array.isArray(res) ? res[0] : res;
      if (found) setCustomer(found); else setNotFound(true);
    } catch (e) {
      if (e.response?.status === 404) setNotFound(true); else setError(errorMessage(e));
    }
  }

  async function quickAdd() {
    setError('');
    try {
      const created = await createCustomer({ name: newName.trim(), phoneNumber: phone.trim(), email: null });
      setCustomer(created); setNotFound(false); setNewName('');
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  // ---- item rows ----
  function updateRow(key, changes) {
    setRows((current) => current.map((r) => (r.key === key ? { ...r, ...changes } : r)));
  }

  function onProductText(key, text) {
    const match = products.find((p) => p.name.toLowerCase() === text.trim().toLowerCase());
    updateRow(key, {
      text,
      product: match || null,
      price: match ? String(match.defaultPrice ?? '') : '', // auto-fill, still editable
    });
  }

  const removeRow = (key) => setRows((current) => (current.length > 1 ? current.filter((r) => r.key !== key) : current));
  const addRow = () => setRows((current) => [...current, newRow()]);

  const lineTotal = (r) => (Number(r.quantity) || 0) * (Number(r.price) || 0);
  const total = rows.reduce((sum, r) => sum + lineTotal(r), 0);

  // ---- submit ----
  async function completeSale() {
    setError(''); setMessage('');
    if (!customer) { setError('Find or add the customer first'); return; }
    const valid = rows.filter((r) => r.product);
    if (valid.length === 0) { setError('Add at least one product'); return; }
    if (valid.some((r) => !Number.isInteger(Number(r.quantity)) || Number(r.quantity) < 1)) {
      setError('Quantities must be whole numbers, 1 or more');
      return;
    }

    setBusy(true);
    try {
      const res = await createTransaction({
        customerId: customer.id,
        date: today(),
        items: valid.map((r) => ({
          productId: r.product.id,
          quantity: Number(r.quantity),
          price: r.price === '' ? null : Number(r.price), // null = backend uses the default price
        })),
        sendBill: skipSend ? false : null, // null = follow the saved preference
      });
      setMessage(
        `Sale saved. Bill #${res.billNumber}` + (res.billSendRequested ? ' (bill number sent to customer)' : '')
      );
      setRows([newRow()]);
      setSkipSend(false);
      setProducts(await getProducts()); // stock changed, refresh
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  const willSend = prefs?.sendBillMode === 'ALWAYS';

  return (
    <div>
      <h2>Regular Billing</h2>

      {/* Customer */}
      <div>
        <input placeholder="Customer phone" value={phone} onChange={(e) => setPhone(e.target.value)} />{' '}
        <button onClick={findCustomer}>Find</button>
      </div>
      {customer && <p>Billing to: <strong>{customer.name}</strong> · {customer.phoneNumber}</p>}
      {notFound && (
        <p>
          No customer with this number.{' '}
          <input placeholder="New customer name" value={newName} onChange={(e) => setNewName(e.target.value)} />{' '}
          <button onClick={quickAdd} disabled={!newName.trim()}>Add &amp; use</button>
        </p>
      )}

      {/* Items */}
      <datalist id="product-suggestions">
        {products.map((p) => <option key={p.id} value={p.name} />)}
      </datalist>

      <table>
        <thead>
          <tr><th>Product</th><th>Qty</th><th>Price</th><th>Line total</th><th></th></tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.key}>
              <td>
                <input
                  list="product-suggestions"
                  placeholder="Type product name…"
                  value={r.text}
                  onChange={(e) => onProductText(r.key, e.target.value)}
                />
                {r.text && !r.product && <small style={{ color: 'crimson' }}> pick from the list</small>}
              </td>
              <td><input type="number" min="1" step="1" style={{ width: 70 }} value={r.quantity}
                         onChange={(e) => updateRow(r.key, { quantity: e.target.value })} /></td>
              <td><input type="number" min="0" style={{ width: 90 }} value={r.price}
                         onChange={(e) => updateRow(r.key, { price: e.target.value })} /></td>
              <td>{money(lineTotal(r))}</td>
              <td><button aria-label="Remove row" onClick={() => removeRow(r.key)}>×</button></td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={addRow}>+ Add item</button>

      {/* Total + bill number */}
      <h3>Total: {money(total)}</h3>

      {prefs && (
        <div>
          {willSend
            ? <p>Bill number will be sent via {prefs.billChannel === 'SMS' ? 'SMS' : 'WhatsApp'}.</p>
            : <p>Bill number will not be sent (change in Preferences).</p>}
          {willSend && (
            <label>
              <input type="checkbox" checked={skipSend} onChange={(e) => setSkipSend(e.target.checked)} /> Don't send for this bill
            </label>
          )}
        </div>
      )}

      {error && <p style={{ color: 'crimson' }}>{error}</p>}
      {message && <p style={{ color: 'green' }}>{message}</p>}
      <button onClick={completeSale} disabled={busy}>{busy ? 'Saving…' : 'Complete sale'}</button>
    </div>
  );
}
