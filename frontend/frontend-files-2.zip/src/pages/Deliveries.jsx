import { useEffect, useState } from 'react';
import { getSuppliers, recordDelivery } from '../api/suppliers';
import { getProducts, createProduct } from '../api/products';
import { errorMessage } from '../api/client';
import { money } from '../utils/format';

const today = () => new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD in local time
const newRow = () => ({ key: crypto.randomUUID(), text: '', product: null, quantity: '1', price: '' });
const emptyProduct = { name: '', unit: '', defaultPrice: '' };

export default function Deliveries() {
  const [suppliers, setSuppliers] = useState([]);
  const [products, setProducts] = useState([]);

  const [supplierId, setSupplierId] = useState('');
  const [date, setDate] = useState(today());
  const [description, setDescription] = useState('');
  const [rows, setRows] = useState([newRow()]);

  const [productForm, setProductForm] = useState(emptyProduct);

  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [productMessage, setProductMessage] = useState('');
  const [productError, setProductError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    Promise.all([getSuppliers(), getProducts()])
      .then(([s, p]) => { setSuppliers(s); setProducts(p); })
      .catch((e) => setError(errorMessage(e)));
  }, []);

  // ---- delivery rows ----
  function updateRow(key, changes) {
    setRows((current) => current.map((r) => (r.key === key ? { ...r, ...changes } : r)));
  }

  function onProductText(key, text) {
    const match = products.find((p) => p.name.toLowerCase() === text.trim().toLowerCase());
    updateRow(key, { text, product: match || null });
  }

  const removeRow = (key) => setRows((current) => (current.length > 1 ? current.filter((r) => r.key !== key) : current));
  const addRow = () => setRows((current) => [...current, newRow()]);

  const lineTotal = (r) => (Number(r.quantity) || 0) * (Number(r.price) || 0);
  const total = rows.reduce((sum, r) => sum + lineTotal(r), 0);

  async function handleSave() {
    setError(''); setMessage('');
    if (!supplierId) { setError('Choose a supplier'); return; }
    const valid = rows.filter((r) => r.product);
    if (valid.length === 0) { setError('Add at least one product'); return; }
    if (valid.some((r) => !Number.isInteger(Number(r.quantity)) || Number(r.quantity) < 1)) {
      setError('Quantities must be whole numbers, 1 or more'); return;
    }
    if (valid.some((r) => !(Number(r.price) > 0))) {
      setError('Enter the cost price for every item'); return;
    }

    setBusy(true);
    try {
      await recordDelivery(supplierId, {
        date,
        description: description.trim() || null,
        items: valid.map((r) => ({
          productId: r.product.id,
          quantity: Number(r.quantity),
          price: Number(r.price),
        })),
      });
      setMessage('Delivery recorded. Stock updated.');
      setRows([newRow()]);
      setDescription('');
      setProducts(await getProducts()); // stock changed
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  // ---- add product ----
  async function handleAddProduct(e) {
    e.preventDefault();
    setProductError(''); setProductMessage('');
    try {
      await createProduct({
        name: productForm.name.trim(),
        unit: productForm.unit.trim() || null,
        defaultPrice: productForm.defaultPrice === '' ? null : Number(productForm.defaultPrice),
        currentStock: 0,
      });
      setProductForm(emptyProduct);
      setProductMessage('Product added');
      setProducts(await getProducts());
    } catch (err) {
      setProductError(errorMessage(err));
    }
  }

  const setProductField = (name) => (e) => setProductForm({ ...productForm, [name]: e.target.value });

  return (
    <div>
      <h2>Deliveries</h2>

      <div className="columns">
        <div className="main">
          <div className="card stack">
            <h3>Record a delivery</h3>

            <div className="row">
              <select value={supplierId} onChange={(e) => setSupplierId(e.target.value)} style={{ minWidth: 240 }}>
                <option value="">Select supplier</option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>{s.companyName} – {s.dealerName}</option>
                ))}
              </select>
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              <input
                placeholder="Note (optional), e.g. Weekly restock"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                style={{ flex: 1, minWidth: 200 }}
              />
            </div>

            <datalist id="delivery-products">
              {products.map((p) => <option key={p.id} value={p.name} />)}
            </datalist>

            <div className="scroll-x">
              <table>
                <thead>
                  <tr><th>Product</th><th>Qty</th><th>Cost price</th><th>Line total</th><th></th></tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.key}>
                      <td>
                        <input
                          list="delivery-products"
                          placeholder="Type product name…"
                          value={r.text}
                          onChange={(e) => onProductText(r.key, e.target.value)}
                        />
                        {r.text && !r.product && <small className="error"> pick from the list</small>}
                      </td>
                      <td><input type="number" min="1" step="1" style={{ width: 80 }} value={r.quantity}
                                 onChange={(e) => updateRow(r.key, { quantity: e.target.value })} /></td>
                      <td><input type="number" min="0" style={{ width: 100 }} value={r.price}
                                 onChange={(e) => updateRow(r.key, { price: e.target.value })} /></td>
                      <td>{money(lineTotal(r))}</td>
                      <td><button className="danger" aria-label="Remove row" onClick={() => removeRow(r.key)}>×</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="row" style={{ justifyContent: 'space-between' }}>
              <button className="secondary" onClick={addRow}>+ Add item row</button>
              <strong style={{ fontSize: 18 }}>Total: {money(total)}</strong>
            </div>

            {error && <p className="error">{error}</p>}
            {message && <p className="success">{message}</p>}
            <button onClick={handleSave} disabled={busy}>
              {busy ? 'Saving…' : 'Save delivery & update stock'}
            </button>
          </div>
        </div>

        <div className="side">
          <div className="card">
            <h3>Stock</h3>
            <p className="muted">Current stock per product. Updates after each delivery or sale.</p>
            <div className="scroll-x">
              <table>
                <thead><tr><th>Product</th><th>In stock</th><th>Price</th></tr></thead>
                <tbody>
                  {products.length === 0 && <tr><td colSpan="3" className="muted">No products yet.</td></tr>}
                  {products.map((p) => (
                    <tr key={p.id}>
                      <td>{p.name}</td>
                      <td>{p.currentStock} {p.unit || ''}</td>
                      <td>{p.defaultPrice != null ? money(p.defaultPrice) : '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <form className="card stack" onSubmit={handleAddProduct}>
            <h3>Add a new product</h3>
            <p className="muted">Put the size in the name, e.g. “Apple Juice 1L”.</p>
            <input placeholder="Product name" value={productForm.name} onChange={setProductField('name')} required />
            <input placeholder="Unit (kg, pcs, bottles)" value={productForm.unit} onChange={setProductField('unit')} />
            <input type="number" min="0" placeholder="Selling price" value={productForm.defaultPrice}
                   onChange={setProductField('defaultPrice')} />
            {productError && <p className="error">{productError}</p>}
            {productMessage && <p className="success">{productMessage}</p>}
            <button type="submit">Add product</button>
          </form>
        </div>
      </div>
    </div>
  );
}
